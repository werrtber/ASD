#include <iostream>
#include <gtest/gtest.h>
using namespace std;

struct Tree {
    int value;
    Tree* left;
    Tree* right;
    int height;

    Tree(int val) : value(val), left(nullptr), right(nullptr), height(1) {}
};

int height(Tree* node) {
    if (node == nullptr)
        return 0;
    return node->height;
}

int max(int a, int b) {
    if (a > b)
        return a;
    else
        return b;
}

Tree* rightRotate(Tree* unbalancedNode) {
    Tree* leftSubtree = unbalancedNode->left;
    Tree* subtree = leftSubtree->right;

    leftSubtree->right = unbalancedNode;
    unbalancedNode->left = subtree;

    unbalancedNode->height = max(height(unbalancedNode->left), height(unbalancedNode->right)) + 1;
    leftSubtree->height = max(height(leftSubtree->left), height(leftSubtree->right)) + 1;

    return leftSubtree;
}

Tree* leftRotate(Tree* unbalancedNode) {
    Tree* rightSubtree = unbalancedNode->right;
    Tree* subtree = rightSubtree->left;

    rightSubtree->left = unbalancedNode;
    unbalancedNode->right = subtree;

    unbalancedNode->height = max(height(unbalancedNode->left), height(unbalancedNode->right)) + 1;
    rightSubtree->height = max(height(rightSubtree->left), height(rightSubtree->right)) + 1;

    return rightSubtree;
}

int getBalance(Tree* node) {
    if (node == nullptr)
        return 0;
    return height(node->left) - height(node->right);
}

Tree* insert(Tree* tree, int value) {
    if (tree == nullptr)
        return new Tree(value);

    if (value < tree->value)
        tree->left = insert(tree->left, value);
    else if (value > tree->value)
        tree->right = insert(tree->right, value);
    else
        return tree;

    tree->height = 1 + max(height(tree->left), height(tree->right));

    int balance = getBalance(tree);

    if (balance > 1 && value < tree->left->value)
        return rightRotate(tree);

    if (balance < -1 && value > tree->right->value)
        return leftRotate(tree);

    if (balance > 1 && value > tree->left->value) {
        tree->left = leftRotate(tree->left);
        return rightRotate(tree);
    }

    if (balance < -1 && value < tree->right->value) {
        tree->right = rightRotate(tree->right);
        return leftRotate(tree);
    }

    return tree;
}

void printTree(Tree* root, int space = 0, int height = 10) {
    if (root == nullptr)
        return;

    space += height;

    printTree(root->right, space);

    cout << endl;
    for (int i = height; i < space; i++)
        cout << " ";
    cout << root->value << "\n";

    printTree(root->left, space);
}

TEST(AVLTreeTest, HeightTest) {
    Tree* node = new Tree(5);
    EXPECT_EQ(height(node), 1);
}

TEST(AVLTreeTest, MaxTest) {
    EXPECT_EQ(max(5, 10), 10);
    EXPECT_EQ(max(100, 50), 100);
    EXPECT_EQ(max(0, -5), 0);
}

TEST(AVLTreeTest, RightRotateTest) {
    Tree* node1 = new Tree(5);
    Tree* node2 = new Tree(10);
    node1->left = new Tree(3);
    node1->right = node2;

    Tree* result = rightRotate(node1);
    EXPECT_EQ(result->value, 3);
    EXPECT_EQ(result->right->value, 5);
    EXPECT_EQ(result->right->right->value, 10);
}

TEST(AVLTreeTest, LeftRotateTest) {
    Tree* node1 = new Tree(10);
    Tree* node2 = new Tree(5);
    node1->right = new Tree(15);
    node1->left = node2;

    Tree* result = leftRotate(node1);
    EXPECT_EQ(result->value, 15);
    EXPECT_EQ(result->left->value, 10);
    EXPECT_EQ(result->left->left->value, 5);
}

TEST(AVLTreeTest, GetBalanceTest) {
    Tree* node1 = new Tree(10);
    node1->left = new Tree(5);
    node1->right = new Tree(15);
    EXPECT_EQ(getBalance(node1), 0);
}
TEST(AVLTreeTest, InsertTest) {
    Tree* root = nullptr;

    root = insert(root, 5);
    root = insert(root, 9);
    root = insert(root, 4);
    root = insert(root, 18);
    root = insert(root, 50);
    root = insert(root, 13);

    EXPECT_EQ(root->value, 9);
    EXPECT_EQ(root->left->value, 5);
    EXPECT_EQ(root->right->value, 18);
    EXPECT_EQ(root->left->left->value, 4);
    EXPECT_EQ(root->right->left->value, 13);
    EXPECT_EQ(root->right->right->value, 50);
}


int main(int argc, char** argv) {
    Tree* root = nullptr;

    root = insert(root, 5);
    root = insert(root, 9);
    root = insert(root, 4);
    root = insert(root, 18);
    root = insert(root, 50);
    root = insert(root, 13);

    cout << "AVL Tree structure:\n";
    printTree(root);
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
