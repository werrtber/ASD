﻿#include <iostream>
#include <gtest/gtest.h>
#include <sstream>
#include <cctype>

using namespace std;

class Stack {
private:
    struct Node {
        int data;
        Node* next;
        Node(int value) : data(value), next(nullptr) {}
    };

    Node* topNode;

public:
    Stack() : topNode(nullptr) {}

    ~Stack() {
        while (!isEmpty()) {
            pop();
        }
    }

    void push(int value) {
        Node* newNode = new Node(value);
        newNode->next = topNode;
        topNode = newNode;
    }

    int pop() {
        if (isEmpty()) {
            cerr << "Error: Trying to pop from an empty stack" << endl;
            exit(1);
        }
        int value = topNode->data;
        Node* temp = topNode;
        topNode = topNode->next;
        delete temp;
        return value;
    }

    int peek() {
        if (isEmpty()) {
            cerr << "Error: Trying to peek from an empty stack" << endl;
            exit(1);
        }
        return topNode->data;
    }

    bool isEmpty() {
        return topNode == nullptr;
    }
};

bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

int precedence(char op) {
    switch (op) {
    case '*': case '/': return 2;
    case '+': case '-': return 1;
    default: return 0;
    }
}

string toPostfix(string infix) {
    string postfix;
    Stack operators;
    istringstream iss(infix);
    string token;

    while (iss >> token) {
        if (isdigit(token[0])) {
            postfix += token + " ";
        }
        else if (token.size() == 1 && isOperator(token[0])) {
            while (!operators.isEmpty() && precedence(operators.peek()) >= precedence(token[0])) {
                postfix += operators.pop();
                postfix += " ";
            }
            operators.push(token[0]);
        }
        else if (token[0] == '(') {
            operators.push('(');
        }
        else if (token[0] == ')') {
            while (operators.peek() != '(') {
                postfix += operators.pop();
                postfix += " ";
            }
            operators.pop();
        }
    }

    while (!operators.isEmpty()) {
        postfix += operators.pop();
        postfix += " ";
    }

    return postfix;
}

int calculate(string expr) {
    Stack operands;
    istringstream iss(expr);
    string token;

    while (iss >> token) {
        if (isdigit(token[0])) {
            operands.push(stoi(token));
        }
        else if (token.size() == 1 && isOperator(token[0])) {
            int right = operands.pop();
            int left = operands.pop();
            switch (token[0]) {
            case '+': operands.push(left + right); break;
            case '-': operands.push(left - right); break;
            case '*': operands.push(left * right); break;
            case '/': operands.push(left / right); break;
            }
        }
    }

    return operands.pop();
}

TEST(StackTest, PushAndPop) {
    Stack stack;
    stack.push(5);
    stack.push(10);
    stack.push(15);
    ASSERT_EQ(stack.pop(), 15);
    ASSERT_EQ(stack.pop(), 10);
    ASSERT_EQ(stack.pop(), 5);
}

TEST(StackTest, Peek) {
    Stack stack;
    stack.push(5);
    stack.push(10);
    stack.push(15);
    ASSERT_EQ(stack.peek(), 15);
    stack.pop();
    ASSERT_EQ(stack.peek(), 10);
}

TEST(StackTest, IsEmpty) {
    Stack stack;
    ASSERT_TRUE(stack.isEmpty());
    stack.push(5);
    ASSERT_FALSE(stack.isEmpty());
    stack.pop();
    ASSERT_TRUE(stack.isEmpty());
}

TEST(ToPostfixTest, BasicInfixToPostfix) {
    ASSERT_EQ(toPostfix("5 + 3 * 2"), "5 3 2 * + ");
    ASSERT_EQ(toPostfix("( 5 + 3 ) * 2"), "5 3 + 2 * ");
    ASSERT_EQ(toPostfix("1 + 2 * 3 - 4 / 2"), "1 2 3 * + 4 2 / - ");
    ASSERT_EQ(toPostfix("3 * ( 4 + 5 ) - 6 / ( 1 + 2 )"), "3 4 5 + * 6 1 2 + / - ");
}

TEST(CalculateTest, BasicCalculation) {
    ASSERT_EQ(calculate("5 3 2 * + "), 11);
    ASSERT_EQ(calculate("5 3 + 2 * "), 16);
    ASSERT_EQ(calculate("1 2 3 * + 4 2 / - "), 5);
    ASSERT_EQ(calculate("* / 9 3 + * 2 4 - 7 6 "), 27);
}

TEST(CalculateTest, DivisionByZero) {
    ASSERT_THROW(calculate("5 0 /"), std::runtime_error);
}



int main(int argc, char** argv) {
    string source, post;
    cout << "Enter infix notation: \n";
    getline(cin, source);
    if (source.empty()) return 0;
    post = toPostfix(source);
    cout << "Postfix notation: " << post << '\n';
    cout << "Result: " << calculate(post) << "\n\n";


    system("pause");
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}