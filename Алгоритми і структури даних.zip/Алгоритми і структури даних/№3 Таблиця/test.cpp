#include "pch.h"
#include "C:\Users\Admin\source\repos\�������\�������\Source.cpp"

TEST(TableTest, EmptyTable) {
    Table table(3);
    EXPECT_EQ(0, table.getCount());
    EXPECT_FALSE(table.contain(200));
    EXPECT_THROW(table.getValue(200), std::runtime_error);
}

TEST(TableTest, PutAndGet) {
    Table table(3);
    table.put(200, "Ukraine");
    table.put(2958, "France");
    table.put(3131, "UK");

    EXPECT_EQ(3, table.getCount());
    EXPECT_EQ("Ukraine", table.getValue(200));
    EXPECT_EQ("France", table.getValue(2958));
    EXPECT_EQ("UK", table.getValue(3131));
}

TEST(TableTest, Delete) {
    Table table(3);
    table.put(200, "Ukraine");
    table.put(2958, "France");
    table.put(3131, "UK");

    table.delet(2958);
    EXPECT_EQ(2, table.getCount());
    EXPECT_FALSE(table.contain(2958));
    EXPECT_THROW(table.getValue(2958), std::runtime_error);
}

TEST(TableTest, Resize) {
    Table table(2);
    table.put(200, "Ukraine");
    table.put(2958, "France");
    table.put(3131, "UK");

    EXPECT_EQ(3, table.getCount());
    EXPECT_EQ("Ukraine", table.getValue(200));
    EXPECT_EQ("France", table.getValue(2958));
    EXPECT_EQ("UK", table.getValue(3131));
}

TEST(TableTest, KeysAndValues) {
    Table table(3);
    table.put(200, "Ukraine");
    table.put(2958, "France");
    table.put(3131, "UK");

    int* keys = table.getKeys();
    string* values = table.getValues();

    EXPECT_EQ(200, keys[0]);
    EXPECT_EQ(2958, keys[1]);
    EXPECT_EQ(3131, keys[2]);

    EXPECT_EQ("Ukraine", values[0]);
    EXPECT_EQ("France", values[1]);
    EXPECT_EQ("UK", values[2]);

    delete[] keys;
    delete[] values;
}

TEST(TableTest, OverwriteValue) {
    Table table(3);
    table.put(200, "Ukraine");
    table.put(200, "Russia");

    EXPECT_EQ("Russia", table.getValue(200));
}

TEST(TableTest, EmptyDeletion) {
    Table table(3);

    EXPECT_THROW(table.delet(200), std::out_of_range);
}

TEST(TableTest, Contain) {
    Table table(3);
    table.put(200, "Ukraine");
    table.put(2958, "France");
    table.put(3131, "UK");

    EXPECT_TRUE(table.contain(2958));
    EXPECT_FALSE(table.contain(61345));
}

TEST(TableTest, OperatorBracket) {
    Table table(3);
    table.put(200, "Ukraine");

    EXPECT_EQ("Ukraine", table[200]);
}

TEST(TableTest, GetKey) {
    Table table(3);
    table.put(200, "Ukraine");
    table.put(2958, "France");
    table.put(3131, "UK");

    EXPECT_EQ(200, table.getKey("Ukraine"));
    EXPECT_EQ(2958, table.getKey("France"));
    EXPECT_EQ(3131, table.getKey("UK"));
    EXPECT_EQ(-1, table.getKey("Germany"));
}

TEST(TableTest, StressTest) {
    Table table(3);
    for (int i = 0; i < 1000; ++i) {
        table.put(i, to_string(i));
    }

    for (int i = 0; i < 1000; ++i) {
        EXPECT_EQ(to_string(i), table.getValue(i));
    }
}

TEST(TableTest, LargeTable) {
    Table table(10000);
    for (int i = 0; i < 10000; ++i) {
        table.put(i, to_string(i));
    }

    for (int i = 0; i < 10000; ++i) {
        EXPECT_EQ(to_string(i), table.getValue(i));
    }
}
