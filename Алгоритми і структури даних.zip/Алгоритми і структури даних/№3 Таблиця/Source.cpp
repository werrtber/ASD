#pragma once
#include <string>
#include <iostream>
#include<gtest/gtest.h>

using namespace std;


class Table
{
public:

    struct KeyNode
    {
        unsigned int key;
        int index;
    };
    struct ValueNode
    {
        string value;
        int index;

    };

private:
    int size;
    int count;
    int place;
    KeyNode* keys;
    ValueNode* values;
    void new_size();
    void squeez();
    bool find(int key, int& i);
    void store(int key, const string& value, int i);
public:
    Table(int startSize);
    ~Table();
    int getCount();
    Table& put(int key, const string& value);
    Table& delet(int key);
    bool contain(int key);
    string& getValue(int key);
    int getKey(const string& value);
    string& operator[](int key);
    void print();
    int* getKeys();
    string* getValues();

};


int main(int argc, char** argv)
{
    cout << "-------------" << endl;
    Table countries_table(3);
    countries_table.print();
    cout << "Table is created. Number of entries: " << countries_table.getCount() << endl;
    countries_table.put(200, "Ukraine");
    countries_table.put(2958, "France").put(3131, "UK");
    countries_table.print();
    cout << "---Number of entries: " << countries_table.getCount() << endl;
    countries_table.delet(200).print();
    cout << "---Number of entries: " << countries_table.getCount() << endl;
    countries_table.put(314, "Columbia").put(253, "Portugal").print();
    cout << "---Table is resized. Number of entries: " << countries_table.getCount() << endl;
    cout << "-------------" << endl;
    cout << "Does the table contain the key [2958]? " << countries_table.contain(2958) << endl;
    cout << "Does the table contain the key [61345]? " << countries_table.contain(61345) << endl;
    int* keys = countries_table.getKeys();
    cout << "Keys (number of VVP): ";
    for (int i = 0; i < countries_table.getCount(); i++) {
        cout << keys[i] << " ";
    }
    string* values = countries_table.getValues();

    cout << endl;
    cout << "Values (countries): ";
    for (int i = 0; i < countries_table.getCount(); i++) {
        cout << values[i] << " ";
    }

    cout << endl;
    delete[] keys;
    delete[] values;
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
    
}


Table::Table(int startSize)
    : size(startSize), count(0), place(0)
{
    keys = new KeyNode[size];
    values = new ValueNode[size];
}

Table::~Table()
{
    delete[] keys;
    delete[] values;
}

void Table::new_size()
{
    int newSize = size + 100;
    KeyNode* newKeys = new KeyNode[newSize];
    ValueNode* newValues = new ValueNode[newSize];
    for (int i = 0; i < size; i++) {
        newKeys[i] = keys[i];
        newValues[i] = values[i];
    }
    delete[] keys;
    delete[] values;
    keys = newKeys;
    values = newValues;
    size = newSize;
}

void Table::squeez()
{
    while (values[place - 1].index == -1)
        --place;
    for (int i = 0; i < place; i++)
    {
        if (values[i].index == -1)
        {
            values[i] = values[--place];
            keys[values[i].index].index = i;
        }
    }
}

bool Table::find(int key, int& index)
{
    int a = 0; int b = count - 1;
    while (a <= b)
    {
        int c = (a + b) / 2;
        if (key == keys[c].key)
        {
            index = c;
            return true;
        }
        if (key < keys[c].key)
        {
            b = c - 1;
        }
        else
        {
            a = c + 1;
        }
    }
    index = a;
    return false;
}

void Table::store(int key, const string& value, int i)
{
    if (count == size) new_size();
    if (place == size) squeez();
    for (int j = count; j > i; --j)
    {
        keys[j] = keys[j - 1];
        values[keys[j].index].index = j;
    }
    keys[i].key = key; keys[i].index = place;
    values[place].value = value; values[place].index = i;
    ++count;
    ++place;
}

int Table::getCount()
{
    return count;
}

Table& Table::put(int key, const string& value)
{
    int i;
    if (find(key, i))
    {
        values[keys[i].index].value = value;
    }
    else
    {
        store(key, value, i);
    }
    return *this;
}
Table& Table::delet(int key)
{
    if (count == 0) {
        throw std::out_of_range("Table is empty, cannot erase.");
    }
    int index;
    if (find(key, index)) {
        for (int i = index; i < count - 1; i++) {
            keys[i] = keys[i + 1];
            values[i] = values[i + 1];
        }
        count--;
        place--;
    }
    return *this;
}

bool Table::contain(int key)
{
    if (count == 0) {
        cout << "Table is empty" << endl;
        return false;
    }
    int index;
    return find(key, index);
}

string& Table::getValue(int key)
{
    for (int i = 0; i < place; ++i)
    {
        if (keys[i].index != -1 && keys[i].key == key)
        {
            return values[keys[i].index].value;
        }
    }
    throw runtime_error("Key not found");
}

int Table::getKey(const string& value)
{
    for (int i = 0; i < place; ++i)
    {
        if (values[i].index != -1 && values[i].value == value)
        {
            return keys[values[i].index].key;
        }
    }
    return-1;
}

string& Table::operator[](int key)
{
    return getValue(key);
}

void Table::print()
{
    cout << "Keys: ";
    for (int i = 0; i < count; i++)
    {
        cout << keys[i].key << " ";
    }
    cout << endl << "Values: ";
    for (int i = 0; i < count; i++)
    {
        cout << values[i].value << " ";
    }
    cout << endl;
}
int* Table::getKeys()
{
    if (count == 0) {
        cout << "Table is empty" << endl;
        return nullptr;
    }
    int* result = new int[count];
    for (int i = 0; i < count; i++) {
        result[i] = keys[i].key;
    }
    return result;

}

string* Table::getValues()
{
    if (count == 0) {
        cout << "Table is empty" << endl;
        return nullptr;
    }
    string* result = new string[count];
    for (int i = 0; i < count; i++) {
        result[i] = values[i].value;
    }
    return result;
}