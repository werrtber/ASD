#include<iostream>
#include<cmath>
#include<chrono>

using namespace std;

void quickSort(int arr[], int first, int last)
{
    int middle = arr[(first + last) / 2];
    int i = first;
    int j = last;

    do
    {
        while (arr[i] < middle)
            i++;
        while (arr[j] > middle)
            j--;
        if (i <= j)
        {
            swap(arr[i], arr[j]);
            i++;
            j--;
        }
    } while (i <= j);
    if (j > first)
        quickSort(arr, first, j);
    if (i < last)
        quickSort(arr, i, last);
}


int main()
{
	
    const int size = 100; 
    int arr[size];

    
    srand(time(NULL)); 

    
    for (int i = 0; i < size; ++i)
    {
        arr[i] = rand() % 201 - 100; 
    }

    cout << "Before sorting: ";
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;

    quickSort(arr, 0, size - 1);

    cout << "After sorting: ";
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;

    auto start = chrono::high_resolution_clock::now();
    quickSort(arr, 0, size - 1);
    auto end = chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration = end - start;
    std::cout << "time: " << duration.count() << " miliseconds" << std::endl;

    return 0;
}