#include<iostream>
#include<cmath>
#include<chrono>

using namespace std;


void countingSort(int arr[], int n) {
    const int range = 201;
    int count[range] = { 0 };
    for (int i = 0; i < n; i++) {
        count[arr[i] + 100]++;
    }
    int index = 0;
    for (int i = 0; i < range; i++) {
        while (count[i] > 0) {
            arr[index] = i - 100;
            index++;
            count[i]--;
        }
    }
}

int main()
{
    const int size = 100;
    int arr[size];


    srand(time(NULL));


    for (int i = 0; i < size; ++i)
    {
        arr[i] = rand() % 201 - 100;
    }

    cout << "Before sorting: ";
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;

    countingSort(arr, size);

    cout << "After sorting: ";
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;

    auto start = chrono::high_resolution_clock::now();
    countingSort(arr, size);
    auto end = chrono::high_resolution_clock::now();
    std::chrono::duration<double, std::milli> duration = end - start;
    std::cout << "time: " << duration.count() << " miliseconds" << std::endl;

    return 0;

}