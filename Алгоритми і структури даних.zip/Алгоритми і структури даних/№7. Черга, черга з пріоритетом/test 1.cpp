#include "pch.h"
#include "C:\Users\Admin\source\repos\Fraction\Fraction\PQueue_Tsvyk.cpp"
TEST(PriorityQueueTest, Push) {
    PriorityQueue<int> myPriorityQueue;
    myPriorityQueue.Push(5, 2);
    ASSERT_EQ(myPriorityQueue.Front(), 5);
    ASSERT_EQ(myPriorityQueue.Size(), 1);
}

TEST(PriorityQueueTest, Pop) {
    PriorityQueue<int> myPriorityQueue;
    myPriorityQueue.Push(5, 2);
    myPriorityQueue.Push(10, 1);
    myPriorityQueue.Pop();
    ASSERT_EQ(myPriorityQueue.Front(), 5);
    ASSERT_EQ(myPriorityQueue.Size(), 1);
}

TEST(PriorityQueueTest, Front) {
    PriorityQueue<int> myPriorityQueue;
    myPriorityQueue.Push(5, 2);
    ASSERT_EQ(myPriorityQueue.Front(), 5);
}

TEST(PriorityQueueTest, Back) {
    PriorityQueue<int> myPriorityQueue;
    myPriorityQueue.Push(5, 2);
    ASSERT_EQ(myPriorityQueue.Back(), 5);
}

TEST(PriorityQueueTest, Size) {
    PriorityQueue<int> myPriorityQueue;
    ASSERT_EQ(myPriorityQueue.Size(), 0);
    myPriorityQueue.Push(5, 2);
    myPriorityQueue.Push(10, 1);
    ASSERT_EQ(myPriorityQueue.Size(), 2);
}

TEST(PriorityQueueTest, IsEmpty) {
    PriorityQueue<int> myPriorityQueue;
    ASSERT_TRUE(myPriorityQueue.IsEmpty());
    myPriorityQueue.Push(5, 2);
    ASSERT_FALSE(myPriorityQueue.IsEmpty());
}