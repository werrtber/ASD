#include<iostream>
#include <gtest/gtest.h>

using namespace std;

template<typename T>
class PriorityQueue {
private:
    struct Node {
        T data;
        int priority;
        Node* previous;
        Node* next;
    };

    Node* head;
    Node* tail;
    size_t queueSize;

    void Copy(const PriorityQueue& other) {
        if (other.queueSize == 0) {
            return;
        }

        head = new Node{ other.head->data, other.head->priority, nullptr, nullptr };
        Node* current = head;
        Node* otherCurrent = other.head->next;

        while (otherCurrent != nullptr) {
            current->next = new Node{ otherCurrent->data, otherCurrent->priority, current, nullptr };
            current = current->next;
            otherCurrent = otherCurrent->next;
        }
        queueSize = other.queueSize;
    }

public:
    PriorityQueue() : head(nullptr), tail(nullptr), queueSize(0) {};
    PriorityQueue(const PriorityQueue& other) : head(nullptr), tail(nullptr), queueSize(0) {
        if (other.queueSize != 0) {
            Copy(other);
        }
    }

    ~PriorityQueue() {
        Clear();
    };

    void Clear() {
        while (head != nullptr) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        tail = nullptr;
        queueSize = 0;
    }

    PriorityQueue& operator=(const PriorityQueue& other) {
        if (this != &other) {
            Clear();
            Copy(other);
        }
        return *this;
    };

    void Push(const T& value, int priority) {
        Node* newNode = new Node{ value, priority, nullptr, nullptr };

        if (queueSize == 0) {
            head = newNode;
            tail = newNode;
        }
        else {
            Node* current = head;
            while (current != nullptr && current->priority <= priority) {
                current = current->next;
            }

            if (current == head) {
                newNode->next = head;
                head->previous = newNode;
                head = newNode;
            }
            else if (current == nullptr) {
                tail->next = newNode;
                newNode->previous = tail;
                tail = newNode;
            }
            else {
                newNode->previous = current->previous;
                newNode->next = current;
                current->previous->next = newNode;
                current->previous = newNode;
            }
        }

        queueSize++;
    };

    void Pop() {
        if (queueSize == 0) {
            return;
        }
        if (queueSize == 1) {
            delete tail;
            head = nullptr;
            tail = nullptr;
        }
        else {
            Node* temp = head;
            head = head->next;
            head->previous = nullptr;
            delete temp;
        }
        queueSize--;
    }

    T& Front() {
        return head->data;
    };

    T& Back() {
        return tail->data;
    };

    bool IsEmpty() const {
        return queueSize == 0;
    }

    size_t Size() const {
        return queueSize;
    }

    void Show() const {
        if (queueSize == 0) {
            cout << "Priority Queue is empty :((\n";
            return;
        }
        Node* current = head;
        while (current != nullptr) {
            cout << current->data << " (Priority: " << current->priority << ") ";
            current = current->next;
        }
        cout << endl;
    }
};
int main(int argc, char** argv) {
    
    PriorityQueue<int> priorityQueue;

    
    priorityQueue.Push(10, 2);
    priorityQueue.Push(20, 1);
    priorityQueue.Push(30, 3);
    priorityQueue.Push(40, 2);
    priorityQueue.Push(50, 1);

    
    cout << "Queue size: " << priorityQueue.Size() << endl;

   
    if (!priorityQueue.IsEmpty()) {
        cout << "Front of the queue: " << priorityQueue.Front() << endl;
        cout << "Back of the queue: " << priorityQueue.Back() << endl;
    }

    
    priorityQueue.Pop();

    
    cout << "Queue size after popping: " << priorityQueue.Size() << endl;

   
    cout << "Elements of the priority queue: ";
    priorityQueue.Show();

    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}