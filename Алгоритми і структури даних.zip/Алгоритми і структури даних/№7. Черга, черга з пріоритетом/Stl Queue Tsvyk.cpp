#include<iostream>
#include<queue>     //Header-file for queue
using namespace std;

int main()
{
    priority_queue<int> p1;
    p1.push(35);
    p1.push(40);
    p1.push(95);
    p1.push(20);
    // queue : 95 40 35 20

    p1.pop();            // queue :  40 35 20
    p1.pop();           // queue :  35  20

    while (!p1.empty())
    {
        cout << ' ' << p1.top();
        p1.pop();
    }

}