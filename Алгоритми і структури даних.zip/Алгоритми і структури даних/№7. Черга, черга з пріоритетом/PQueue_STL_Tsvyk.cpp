#include<iostream>
#include<queue>     
using namespace std;

int main()
{
    priority_queue<int> p1;
    p1.push(35);
    p1.push(40);
    p1.push(95);
    p1.push(20);
   
    cout << "My Queue size:" << p1.size() << endl;

    p1.pop();     
    p1.pop();          
    cout << "My Queue size after pop:" << p1.size() << endl;

    while (!p1.empty())
    {
        cout << " " << p1.top();
        p1.pop();
    }

}