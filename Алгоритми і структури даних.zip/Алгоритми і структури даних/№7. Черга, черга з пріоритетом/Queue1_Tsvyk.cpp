#include <iostream>
#include <cmath>
#include <gtest/gtest.h>

using namespace std;

template<typename T>
class List
{
private:
    struct Node {
        T data;
        Node* previous;
        Node* next;
    };

    Node* head;
    Node* tail;
    size_t listSize;

    void Copy(const List& other)
    {
        if (other.listSize == 0)
        {
            return;
        }

        head = new Node{ other.head->data, nullptr,nullptr };
        Node* current = head;
        Node* otherCurrent = other.head->next;

        while (otherCurrent != nullptr)
        {
            current->next = new Node{ otherCurrent->data, current, nullptr };
            current = current->next;
            otherCurrent = otherCurrent->next;
        }
        listSize = other.listSize;
    }

public:
    List() : head(nullptr), tail(nullptr), listSize(0) {};
    List(const List& other) : head(nullptr), tail(nullptr), listSize(0)
    {
        if (other.listSize != 0)
        {
            Copy(other);
        }
    }

    ~List()
    {
        Clear();
    };

    void Clear()
    {
        while (head != nullptr)
        {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
        tail = nullptr;
        listSize = 0;
    }

    void PushBack(const T& value)
    {
        if (listSize == 0)
        {
            head = new Node{ value,nullptr, nullptr };
            tail = head;
        }
        else
        {
            tail->next = new Node{ value, nullptr, nullptr };
            tail = tail->next;
        }
        listSize++;
    };

    void PopFront()
    {
        if (listSize == 0)
        {
            return;
        }
        if (listSize == 1)
        {
            delete head;
            head = nullptr;
            tail = nullptr;
        }
        else
        {
            Node* temp = head;
            head = head->next;
            head->previous = nullptr;
            delete temp;
        }
        listSize--;
    }

    T& Front()
    {
        return head->data;
    };


    T& Back()
    {
        return tail->data;
    };

    bool IsEmpty() const
    {
        return listSize == 0;
    }

    size_t Size() const
    {
        return listSize;
    }

    void Show() const
    {
        if (listSize == 0)
        {
            cout << "List is empty :((\n";
            return;
        }
        Node* current = head;
        while (current != nullptr)
        {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

template<typename T>
class Queue
{
private:

    List<T> list;

public:
    void Pop();
    void Push(const T& value);
    size_t QueueSize() const;
    bool IsEmpty() const;
    void Show() const;
    T& Front();
    T& Back();
    

};



int main(int argc, char** argv)
{

    Queue<double> myQueue;


    for (double value = 1.0; value < 10; value++)
    {
        myQueue.Push(value);
    }


    cout << "Queue size: " << myQueue.QueueSize() << endl;


    if (!myQueue.IsEmpty())
    {

        cout << "Front of the queue: " << myQueue.Front() << endl;
        cout << "Back of the queue: " << myQueue.Back() << endl;
    }


    myQueue.Pop();


    cout << "Queue size after popping: " << myQueue.QueueSize() << endl;

    myQueue.Show();

    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}




template <typename T>
void Queue<T>::Pop()
{
    list.PopFront();
}

template <typename T>
void Queue<T>::Push(const T& value)
{
    list.PushBack(value);
}

template <typename T>
size_t Queue<T>::QueueSize() const
{
    return list.Size();
}


template<typename T>
bool Queue<T>::IsEmpty() const
{
    return list.IsEmpty();
}


template<typename T>
T& Queue<T>::Front()
{
    return list.Front();
}

template<typename T>
T& Queue<T>::Back()
{
    return list.Back();
}

template <typename T>
void Queue<T>::Show() const
{
    list.Show(); 
}

