#include "pch.h"
#include "D:\my project\Queue1\Queue1\Queue1_Tsvyk.cpp"

TEST(QueueTest, Push) {
    Queue<int> myQueue;
    myQueue.Push(5);
    ASSERT_EQ(myQueue.Front(), 5);
    ASSERT_EQ(myQueue.QueueSize(), 1);
}


TEST(QueueTest, Pop) {
    Queue<int> myQueue;
    myQueue.Push(5);
    myQueue.Push(10);
    myQueue.Pop();
    ASSERT_EQ(myQueue.Front(), 10); 
    ASSERT_EQ(myQueue.QueueSize(), 1); 
}


TEST(QueueTest, Front) {
    Queue<int> myQueue;
    myQueue.Push(5);
    ASSERT_EQ(myQueue.Front(), 5); 
}


TEST(QueueTest, Back) {
    Queue<int> myQueue;
    myQueue.Push(5);
    ASSERT_EQ(myQueue.Back(), 5); 
}


TEST(QueueTest, QueueSize) {
    Queue<int> myQueue;
    ASSERT_EQ(myQueue.QueueSize(), 0); 
    myQueue.Push(5);
    myQueue.Push(10);
    ASSERT_EQ(myQueue.QueueSize(), 2); 
}

TEST(QueueTest, IsEmpty) {
    Queue<int> myQueue;
    ASSERT_TRUE(myQueue.IsEmpty());
    myQueue.Push(5);
    ASSERT_FALSE(myQueue.IsEmpty());
}