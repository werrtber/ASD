#include <iostream> 
#include<stack>
#include<list>
#include<gtest/gtest.h>
using namespace std;
int main(int argc, char* argv[]) {
	stack<int, list<int> > st;
    st.push(1);
    st.push(2);
    st.push(4);
    cout << "top is " << st.top() << endl;
    st.push(7);
    st.push(9);
    cout << "size is " << st.size() << endl;
    cout << "top is " << st.top() << endl;
    st.pop();
    st.pop();
    cout << "top is " << st.top() << endl;
    st.pop();
    st.pop();
    
   
    cout << "top is " << st.top() << endl;

    
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();

}