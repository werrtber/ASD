
#include<iostream>

using namespace std;
#include<gtest/gtest.h>



class Node {
public:
	int value;
	Node* next;
	Node(int n) {
		this->value = n;
		this->next = NULL;
	}
};
class Stack {
	Node* top;
public:
	Stack() { top = NULL; }

	void push(int data)
	{
		Node* temp = new Node(data);
		if (!temp) {
			cout << "\nStack Overflow";
		}
		temp->value = data;
		temp->next = top;
		top = temp;
	}
	
	bool isEmpty()
	{
		return top == NULL;
	}
	int show_top()
	{
		if (!isEmpty())
			return top->value;
		else {

			throw runtime_error("Stack is empty");
		}
	}
	void pop()
	{
		Node* temporary;
		if (top == NULL) {

			throw runtime_error("Stack is empty");
		}
		else {
			temporary = top;
			top = top->next;
			delete temporary;
		}
	}
	void show_stack()
	{
		Node* temp;
		if (top == NULL) {
			cout << "\nStack  is empty";

		}
		else {
			temp = top;
			cout << "stack : " << endl;
			while (temp != NULL) {


				cout << temp->value;


				temp = temp->next;
				if (temp != NULL)
					cout << " -> ";
			}
		}
		cout << endl;
	}
	void clear()
	{
		while (top != NULL) {
			Node* temp = top;
			top = top->next;
			delete temp;
		}
	}
};

int main(int argc, char* argv[]) {
	Stack s;
	s.push(1);
	cout << "top is: " << s.show_top() << endl;
	s.push(2);
	s.push(3);
	s.push(4);

	s.show_stack();
	s.pop();
	cout << "top is: " << s.show_top() << endl;
	s.pop();
	s.pop();
	
	s.show_stack();
	
	s.clear();
	s.show_stack();
	testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();

}



