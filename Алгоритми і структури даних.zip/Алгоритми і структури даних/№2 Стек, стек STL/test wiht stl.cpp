#include "pch.h"
#include "C:\Users\Admin\source\repos\lab with stl\lab with stl\Source.cpp"

TEST(StackTest, PushAndTopTest) {
    std::stack<int, std::list<int>> st;
    st.push(1);
    st.push(2);
    st.push(4);
    EXPECT_EQ(st.top(), 4);
}

TEST(StackTest, SizeTest) {
    std::stack<int, std::list<int>> st;
    st.push(1);
    st.push(2);
    st.push(4);
    EXPECT_EQ(st.size(), 3);
}

TEST(StackTest, PopTest) {
    std::stack<int, std::list<int>> st;
    st.push(1);
    st.push(2);
    st.push(4);
    st.pop();
    EXPECT_EQ(st.top(), 2);
}

TEST(StackTest, EmptyStackTest) {
    std::stack<int, std::list<int>> st;
    EXPECT_TRUE(st.empty());
}

TEST(StackTest, NonEmptyStackTest) {
    std::stack<int, std::list<int>> st;
    st.push(1);
    EXPECT_FALSE(st.empty());
}

TEST(StackTest, ClearTest) {
    std::stack<int, std::list<int>> st;
    st.push(1);
    st.push(2);
    st.push(4);
    st.push(7);
    st.push(9);
    st.pop();
    st.pop();
    st.pop();
    st.pop();
    st.pop();
    EXPECT_TRUE(st.empty());
}
