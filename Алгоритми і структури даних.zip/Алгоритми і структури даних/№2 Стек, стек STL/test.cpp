#include "pch.h"
#include "C:\Users\Admin\source\repos\lab withot stl\lab withot stl\Source.cpp"



TEST(StackTest, PushTest) {
    Stack stack;
    stack.push(1);
    stack.push(2);
    stack.push(3);

    EXPECT_EQ(stack.show_top(), 3);
}
TEST(StackTest, PopTest) {
    Stack stack;
    stack.push(1);
    stack.push(2);
    stack.push(3);

    stack.pop();
    EXPECT_EQ(stack.show_top(), 2);
}
TEST(StackTest, PopEmptyStackTest) {
    Stack stack;

    EXPECT_THROW(stack.pop(), std::runtime_error);
}
TEST(StackTest, IsEmptyTrueTest) {
    Stack stack;

    EXPECT_TRUE(stack.isEmpty());
}
TEST(StackTest, IsEmptyFalseTest) {
    Stack stack;
    stack.push(1);

    EXPECT_FALSE(stack.isEmpty());
}
TEST(StackTest, ShowStackTest) {
    Stack stack;
    stack.push(1);
    stack.push(2);
    stack.push(3);

    testing::internal::CaptureStdout();
    stack.show_stack();
    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_EQ(output, "stack : \n3 -> 2 -> 1\n");
}
TEST(StackTest, ClearStackTest) {
    Stack stack;
    stack.push(1);
    stack.push(2);
    stack.push(3);

    stack.clear();
    EXPECT_TRUE(stack.isEmpty());
}