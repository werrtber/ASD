#include <iostream>
#include <limits.h>
#include "gtest/gtest.h"

using namespace std;

class Graph {
private:
    int V;
    int** adjMatrix;

public:
    Graph(int vertices) {
        V = vertices;
        adjMatrix = new int* [V];
        for (int i = 0; i < V; ++i) {
            adjMatrix[i] = new int[V];
            for (int j = 0; j < V; ++j) {
                adjMatrix[i][j] = 0;
            }
        }
    }

    void addEdge(int u, int v, int weight) {
        adjMatrix[u][v] = weight;
        adjMatrix[v][u] = weight;
    }

    int getWeight(int u, int v) {
        return adjMatrix[u][v];
    }

    int minDistance(int* dist, bool* visited) {
        int min = INT_MAX, min_index;

        for (int v = 0; v < V; ++v) {
            if (visited[v] == false && dist[v] <= min) {
                min = dist[v];
                min_index = v;
            }
        }

        return min_index;
    }

    void dijkstra(int src, int dest) {
        int* dist = new int[V];
        bool* visited = new bool[V];
        int* prev = new int[V];

        for (int i = 0; i < V; ++i) {
            dist[i] = INT_MAX;
            visited[i] = false;
            prev[i] = -1;
        }

        dist[src] = 0;

        for (int count = 0; count < V - 1; ++count) {
            int u = minDistance(dist, visited);
            visited[u] = true;

            for (int v = 0; v < V; ++v) {
                if (!visited[v] && adjMatrix[u][v] && dist[u] != INT_MAX && dist[u] + adjMatrix[u][v] < dist[v]) {
                    dist[v] = dist[u] + adjMatrix[u][v];
                    prev[v] = u;
                }
            }
        }

        cout << "����������� ���� ���� � ������� " << src << " �� ������� " << dest << ": " << dist[dest] << endl;

        if (dist[dest] != INT_MAX) {
            cout << "����: ";
            int current = dest;
            while (current != -1) {
                cout << current;
                if (current != src) {
                    cout << " <- ";
                }
                current = prev[current];
            }
            cout << endl;
        }
        else {
            cout << "������� �� ��������" << endl;
        }

        delete[] dist;
        delete[] visited;
        delete[] prev;
    }
};

TEST(GraphTest, ConstructorAndAddEdge) {
    Graph g(5);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);

    EXPECT_EQ(g.getWeight(0, 1), 4);
    EXPECT_EQ(g.getWeight(1, 0), 4);
    EXPECT_EQ(g.getWeight(1, 2), 3);
    EXPECT_EQ(g.getWeight(2, 1), 3);
    EXPECT_EQ(g.getWeight(2, 3), 2);
    EXPECT_EQ(g.getWeight(3, 2), 2);
    EXPECT_EQ(g.getWeight(0, 3), 0);
}

TEST(GraphTest, GetWeight) {
    Graph g(5);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 2, 5);


    EXPECT_EQ(g.getWeight(0, 1), 4);
    EXPECT_EQ(g.getWeight(1, 0), 4);
    EXPECT_EQ(g.getWeight(1, 2), 3);
    EXPECT_EQ(g.getWeight(2, 1), 3);
    EXPECT_EQ(g.getWeight(2, 3), 2);
    EXPECT_EQ(g.getWeight(3, 2), 2);
    EXPECT_EQ(g.getWeight(0, 3), 0);
}

TEST(GraphTest, MinDistance) {
    Graph g(5);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 2, 5);

    int dist[5] = { 5, 4, 0, 2, INT_MAX };
    bool visited[5] = { false, false, true, false, false };

    EXPECT_EQ(g.minDistance(dist, visited), 3);
}
TEST(GraphTest, AddEdge) {
    Graph g(5);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 2, 5);
    g.addEdge(3, 4, 1);

    EXPECT_EQ(g.getWeight(0, 1), 4);
    EXPECT_EQ(g.getWeight(1, 0), 4);
    EXPECT_EQ(g.getWeight(1, 2), 3);
    EXPECT_EQ(g.getWeight(2, 1), 3);
    EXPECT_EQ(g.getWeight(2, 3), 2);
    EXPECT_EQ(g.getWeight(3, 2), 2);
    EXPECT_EQ(g.getWeight(0, 3), 0);
    EXPECT_EQ(g.getWeight(3, 4), 1);
}

TEST(GraphTest, Dijkstra) {
    Graph g(5);
    g.addEdge(0, 1, 4);
    g.addEdge(1, 2, 3);
    g.addEdge(2, 3, 2);
    g.addEdge(0, 2, 5);

    testing::internal::CaptureStdout();

    g.dijkstra(0, 3);

    std::string output = testing::internal::GetCapturedStdout();

    EXPECT_EQ(output, "����������� ���� ���� � ������� 0 �� ������� 3: 7\n����: 3 <- 2 <- 0\n");
}

int main(int argc, char** argv) {
    setlocale(LC_ALL, "ukr");
    Graph g(9);
    g.addEdge(0, 1, 4);
    g.addEdge(0, 7, 8);
    g.addEdge(1, 2, 8);
    g.addEdge(1, 7, 11);
    g.addEdge(2, 3, 7);
    g.addEdge(2, 8, 2);
    g.addEdge(2, 5, 4);
    g.addEdge(3, 4, 9);
    g.addEdge(3, 5, 14);
    g.addEdge(4, 5, 10);
    g.addEdge(5, 6, 2);
    g.addEdge(6, 7, 1);
    g.addEdge(6, 8, 6);
    g.addEdge(7, 8, 7);

    int src, dest;
    cout << "������ ��������� �������: ";
    cin >> src;
    if (src < 0 || src >= 9) {
        cout << "�������: ������� � ������� " << src << " �� ����." << endl;
        return 1;
    }
    cout << "������ ������ �������: ";
    cin >> dest;
    if (dest < 0 || dest >= 9) {
        cout << "�������: ������� � ������� " << dest << " �� ����." << endl;
        return 1;
    }

    g.dijkstra(src, dest);
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
