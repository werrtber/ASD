#include <iostream>
#include <gtest/gtest.h>
using namespace std;

class BitwiseSet {
private:
    unsigned int data; 

public:
    BitwiseSet() : data(0) {} 

    void add(char letter) {
        if (letter < 'a' || letter > 'z') return; 

        int index = letter - 'a'; 
        unsigned int bitstring = 1 << index; 
        data |= bitstring; 
    }

    void remove(char letter) {
        if (letter < 'a' || letter > 'z') return;

        int index = letter - 'a';
        unsigned int bitstring = 1 << index; 
        data &= ~bitstring; 
    }

    bool contains(char letter) const {
        if (letter < 'a' || letter > 'z') return false;

        int index = letter - 'a';
        unsigned int bitstring = 1 << index; 

        return (data & bitstring) != 0; 
    }

    bool isEmpty() const {
        return data == 0;
    }

    BitwiseSet unionWith(const BitwiseSet& other) const {
        BitwiseSet result;
        result.data = data | other.data; 
        return result;
    }

    BitwiseSet intersectionWith(const BitwiseSet& other) const {
        BitwiseSet result;
        result.data = data & other.data; 
        return result;
    }

    BitwiseSet differenceWith(const BitwiseSet& other) const {
        BitwiseSet result;
        result.data = data & ~other.data; 
        return result;
    }

    void print() const {
        cout << "{ ";
        for (char c = 'a'; c <= 'z'; ++c) {
            if (contains(c)) {
                cout << c << " ";
            }
        }
        cout << "}" << endl;
    }
};

int main(int argc, char** argv) {
    BitwiseSet set1, set2;
    set1.add('a');
    set1.add('b');
    set1.add('c');

    set2.add('b');
    set2.add('c');
    set2.add('d');

    cout << "Set 1: ";
    set1.print(); 

    cout << "Set 2: ";
    set2.print(); 

    cout << "Is set 1 empty: " << boolalpha << set1.isEmpty() << endl; 
    cout << "Is set 2 empty: " << boolalpha << set2.isEmpty() << endl;

    cout << "Set 1 contains 'a': " << boolalpha << set1.contains('a') << endl; 
    cout << "Set 1 contains 'd': " << boolalpha << set1.contains('d') << endl; 

    cout << "Set 1 union with Set 2: ";
    BitwiseSet unionSet = set1.unionWith(set2);
    unionSet.print(); 

    cout << "Set 1 intersection with Set 2: ";
    BitwiseSet intersectionSet = set1.intersectionWith(set2);
    intersectionSet.print(); 

    cout << "Set 1 difference with Set 2: ";
    BitwiseSet differenceSet = set1.differenceWith(set2);
    differenceSet.print(); 

    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
