#include "pch.h"
#include "D:\my project\Mnozyna\Mnozyna\Tsvyk.cpp"

TEST(BitwiseSetTest, AddTest) {
    BitwiseSet set;
    set.add('a');
    EXPECT_TRUE(set.contains('a'));
    EXPECT_FALSE(set.contains('b'));
}

TEST(BitwiseSetTest, RemoveTest) {
    BitwiseSet set;
    set.add('a');
    set.remove('a');
    EXPECT_FALSE(set.contains('a'));
}

TEST(BitwiseSetTest, ContainsTest) {
    BitwiseSet set;
    set.add('a');
    set.add('b');
    set.add('c');
    EXPECT_TRUE(set.contains('a'));
    EXPECT_TRUE(set.contains('b'));
    EXPECT_TRUE(set.contains('c'));
    EXPECT_FALSE(set.contains('d'));
}

TEST(BitwiseSetTest, IsEmptyTest) {
    BitwiseSet set;
    EXPECT_TRUE(set.isEmpty());
    set.add('a');
    EXPECT_FALSE(set.isEmpty());
    set.remove('a');
    EXPECT_TRUE(set.isEmpty());
}

TEST(BitwiseSetTest, UnionWithTest) {
    BitwiseSet set1, set2;
    set1.add('a');
    set1.add('b');
    set2.add('b');
    set2.add('c');
    BitwiseSet unionSet = set1.unionWith(set2);
    EXPECT_TRUE(unionSet.contains('a'));
    EXPECT_TRUE(unionSet.contains('b'));
    EXPECT_TRUE(unionSet.contains('c'));
    EXPECT_FALSE(unionSet.contains('d'));
}

TEST(BitwiseSetTest, IntersectionWithTest) {
    BitwiseSet set1, set2;
    set1.add('a');
    set1.add('b');
    set2.add('b');
    set2.add('c');
    BitwiseSet intersectionSet = set1.intersectionWith(set2);
    EXPECT_FALSE(intersectionSet.contains('a'));
    EXPECT_TRUE(intersectionSet.contains('b'));
    EXPECT_FALSE(intersectionSet.contains('c'));
    EXPECT_FALSE(intersectionSet.contains('d'));
}

TEST(BitwiseSetTest, DifferenceWithTest) {
    BitwiseSet set1, set2;
    set1.add('a');
    set1.add('b');
    set2.add('b');
    set2.add('c');
    BitwiseSet differenceSet = set1.differenceWith(set2);
    EXPECT_TRUE(differenceSet.contains('a'));
    EXPECT_FALSE(differenceSet.contains('b'));
    EXPECT_FALSE(differenceSet.contains('c'));
    EXPECT_FALSE(differenceSet.contains('d'));
}