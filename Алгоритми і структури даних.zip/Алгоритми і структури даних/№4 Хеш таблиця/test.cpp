#include "pch.h"
#include"D:\my project\Hesh table\Hesh table\Source.cpp"

TEST(HashTableTest, InsertTest) {
    HashTable table;
    table.insert("USA", 21427000);
    EXPECT_EQ(table.get("USA"), 21427000);
}

TEST(HashTableTest, GetTest) {
    HashTable table;
    table.insert("USA", 21427000);
    EXPECT_EQ(table.get("USA"), 21427000);
    EXPECT_EQ(table.get("China"), -1); 
}

TEST(HashTableTest, RemoveTest) {
    HashTable table;
    table.insert("USA", 21427000);
    table.remove("USA");
    EXPECT_EQ(table.get("USA"), -1);
}

TEST(HashTableTest, RemoveNonExistingTest) {
    HashTable table;
    table.insert("USA", 21427000);
    table.remove("China"); 
    EXPECT_EQ(table.get("USA"), 21427000); 
}

TEST(HashTableTest, EmptyTableTest) {
    HashTable table;
    EXPECT_TRUE(table.IsTableEmpty());
    table.insert("USA", 21427000);
    EXPECT_FALSE(table.IsTableEmpty());
}
TEST(HashTableTest, CollisionTest) {
    HashTable table;
    table.insert("USA", 21427000);
    table.insert("Sweeden", 14679372); 
    EXPECT_EQ(table.get("USA"), 21427000);
    EXPECT_EQ(table.get("Sweeden"), 14679372);
}
