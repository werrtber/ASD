#include <iostream>
#include <string>
#include<gtest/gtest.h>

using namespace std;

struct Node {
    string key;
    int value;
    Node* next;
    Node(const string& k, int v) : key(k), value(v), next(nullptr) {}
};

class HashTable {
private:
    static const int SIZE = 100;
    Node* table[SIZE];

public:
    HashTable() {
        for (int i = 0; i < SIZE; ++i) {
            table[i] = nullptr;
        }
    }
    ~HashTable() {
        for (int i = 0; i < SIZE; ++i) {
            Node* current = table[i];
            while (current != nullptr) {
                Node* next = current->next;
                delete current;
                current = next;
            }
        }
    }
    int HashFunction(const string& key)
    {
        int hash_code = 0;
        for (int i = 0; i < key.length(); i++) {
            hash_code += key[i];
        }
        return hash_code % SIZE;
    }
    
    void remove(const string& key) {
        int index = HashFunction(key);
        Node* current = table[index];
        Node* prev = nullptr;
        while (current != nullptr) {
            if (current->key == key) {
                if (prev == nullptr) {
                    table[index] = current->next;
                }
                else {
                    prev->next = current->next;
                }
                delete current;
                return;
            }
            prev = current;
            current = current->next;
        }
    }
    void insert(const string& key, int value) {
        int index = HashFunction(key);
        Node* newNode = new Node(key, value);
        if (table[index] == nullptr) {
            table[index] = newNode;
        }
        else {
            newNode->next = table[index];
            table[index] = newNode;
        }
    }
    int get(const string& key) {
        int index = HashFunction(key);
        Node* current = table[index];
        while (current != nullptr) {
            if (current->key == key) {
                return current->value;
            }
            current = current->next;
        }
        return -1;
    }

    void print() {
        if (!IsTableEmpty()) {
            for (int i = 0; i < SIZE; ++i) {
                Node* current = table[i];
                while (current != nullptr) {
                    cout << "Key: " << current->key << ", Value: " << current->value << endl;
                    current = current->next;
                }
            }
        }
        else
            cout << "Table is empty, it`s nothing for print!" << endl;
    }
    bool IsTableEmpty()
    {
        for (int i = 0; i < SIZE; i++) {
            if (table[i] != nullptr) {
                return false;
            }
        }
        return true;
    }


};
int main(int argc, char** argv)
{
    HashTable table;
    table.insert("USA", 21427000);
    table.insert("China", 14342903);
    table.insert("Japan", 5082464);
    cout << "Initial table:" << endl;
    table.print();

    cout << endl;

    string country = "USA";
    cout << "VVP of " << country << ": " << table.get(country) << endl;

    cout << endl;

    table.remove("China");
    cout << "Initial table after remove:" << endl;
    table.print();

    cout << endl;

    table.remove("USA");
    table.remove("Japan");
    table.print();

    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();

}