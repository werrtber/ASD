#include <iostream>
#include <fstream>
#include <gtest/gtest.h>

using namespace std;

class Node {
public:
    int row;
    int col;
    int value;
    Node* left;
    Node* up;

    Node() {
        row = -1;
        col = -1;
        value = 0;
        left = this;
        up = this;
    }

    Node(int v, int r = -1, int c = -1) : value(v), row(r), col(c) {}
};

class SparseMatrix {
private:
    int rowsHsize;
    int colsHsize;
    Node* rowsH;
    Node* colsH;

public:

    int GetRowsHSize() const {
        return rowsHsize;
    }

    int GetColsHSize() const {
        return colsHsize;
    }
    SparseMatrix(int rows, int cols) : rowsHsize(rows), colsHsize(cols) {

        rowsH = new Node[rows];
        colsH = new Node[cols];
        for (int i = 0; i < cols; ++i)
        {
            colsH[i].col = i;
        }
        for (int j = 0; j < rows; ++j)
        {
            rowsH[j].row = j;
        }
    }

    ~SparseMatrix() {
        for (int i = 0; i < rowsHsize; ++i) {
            Node* current = rowsH[i].up;
            while (current->col != -1) {
                Node* to_del = current;
                current = current->up;
                delete to_del;
            }
        }
        delete[] rowsH;
        delete[]colsH;

    }




    SparseMatrix& operator=(const SparseMatrix& other) {
        if (&other == this) {
            return *this;
        }

        rowsHsize = other.rowsHsize;
        colsHsize = other.colsHsize;
        delete[] rowsH;
        delete[] colsH;
        rowsH = new Node[rowsHsize];
        colsH = new Node[colsHsize];
        for (int i = 0; i < rowsHsize; ++i) {
            Node* otherElem = other.rowsH[i].left;
            while (otherElem != &other.rowsH[i]) {
                int j = otherElem->col;
                int m = otherElem->value;
                SetValue(i, j, m);
                otherElem = otherElem->left;
            }
        }
        return *this;
    }

    Node* GetPrevByRow(int i, int j) {
        Node* result = &rowsH[i];
        Node* iterator = rowsH[i].left;
        while (iterator != &rowsH[i]) {
            if (j >= iterator->col) {
                break;
            }
            result = iterator;
            iterator = iterator->left;
        }
        return result;
    }

    Node* GetPrevByCol(int i, int j) {
        Node* result = &colsH[j];
        Node* iterator = colsH[j].up;
        while (iterator != &colsH[j]) {
            if (i >= iterator->row) {
                break;
            }
            result = iterator;
            iterator = iterator->up;
        }
        return result;
    }

    void SetValue(int row, int col, const int value) {
        Node* prevByRow = GetPrevByRow(row, col);
        Node* prevByCol = GetPrevByCol(row, col);
        if (prevByCol->up->row == row && prevByCol->up->col == col) {
            prevByCol->up->value = value;
            if (value == 0) {
                Node* elemToDelete = prevByCol->up;
                prevByCol->up = elemToDelete->up;
                prevByRow->left = elemToDelete->left;
                delete elemToDelete;
            }
        }
        else {
            if (value != 0) {
                Node* newElement = new Node(value, row, col);
                newElement->left = prevByRow->left;
                prevByRow->left = newElement;
                newElement->up = prevByCol->up;
                prevByCol->up = newElement;
            }
        }
    }

    int GetValue(int row, int col) {
        int result = 0;
        Node* prevByCol = GetPrevByCol(row, col);
        if (prevByCol->up->row == row && prevByCol->up->col == col) {
            result = prevByCol->up->value;
        }
        return result;
    }

    void print() {
        for (int i = 0; i < rowsHsize; ++i) {
            for (int j = 0; j < colsHsize; ++j) {
                cout << GetValue(i, j) << " ";
            }
            cout << endl;
        }
    }

    void DeleteValue(int row, int col) {
        Node* prevByCol = GetPrevByCol(row, col);
        if (prevByCol->up->row == row && prevByCol->up->col == col) {
            Node* elemToDelete = prevByCol->up;
            prevByCol->up = elemToDelete->up;
            Node* prevByRow = GetPrevByRow(row, col);
            prevByRow->left = elemToDelete->left;
            delete elemToDelete;
        }
    }


    SparseMatrix AddMatrix(SparseMatrix& other) {
        if (this->colsHsize != other.colsHsize || this->rowsHsize != other.rowsHsize) {
            throw "cannot add different sized matrices";
        }
        SparseMatrix result(rowsHsize, colsHsize);
        for (int i = 0; i < rowsHsize; ++i) {
            for (int j = 0; j < colsHsize; ++j) {
                double sum;
                sum = this->GetValue(i, j) + other.GetValue(i, j);
                result.SetValue(i, j, sum);
            }
        }
        return result;
    }

    SparseMatrix transpose() {
        SparseMatrix transposed(colsHsize, rowsHsize);
        for (int i = 0; i < rowsHsize; ++i) {
            for (int j = 0; j < colsHsize; ++j) {
                transposed.SetValue(j, i, GetValue(i, j));
            }
        }
        return transposed;
    }

    SparseMatrix MultiplyMatrix(SparseMatrix& other) {
        if (this->colsHsize != other.rowsHsize) {
            throw "cannot multiply matrices with incompatible dimensions";
        }
        SparseMatrix result(this->rowsHsize, other.colsHsize);
        for (int i = 0; i < this->rowsHsize; ++i) {
            for (int j = 0; j < other.colsHsize; ++j) {
                double scalarProduct = 0;
                for (int k = 0; k < this->colsHsize; ++k) {
                    scalarProduct += this->GetValue(i, k) * other.GetValue(k, j);
                }
                result.SetValue(i, j, scalarProduct);
            }
        }
        return result;
    }

};
SparseMatrix ReadMatrixFromFile(const string& filename) {
    ifstream fin(filename);
    if (!fin) {
        cerr << "Error: Unable to open the file." << endl;
        exit(1);
    }

    int rows, cols;
    fin >> rows >> cols;
    SparseMatrix matrix(rows, cols);

    int row, col, value;
    while (fin >> row >> col >> value) {
        matrix.SetValue(row, col, value);
    }

    fin.close();
    return matrix;
}

int main(int argc, char** argv) {

    SparseMatrix matrix1 = ReadMatrixFromFile("matrix1.txt");
    SparseMatrix matrix2 = ReadMatrixFromFile("matrix2.txt");

    cout << "Matrix 1:" << endl;

    matrix1.print();
    cout << endl;

    cout << "Matrix 2:" << endl;

    matrix2.print();
    cout << endl;


    if (matrix1.GetColsHSize() != matrix2.GetColsHSize() || matrix1.GetRowsHSize() != matrix2.GetRowsHSize()) {
        cerr << "Error: cannot add or multiply different sized matrices" << endl;
        return 1;
    }


    matrix1.DeleteValue(0, 2);
    cout << "Matrix 1 after deletion:" << endl;
    matrix1.print();


    SparseMatrix sum = matrix1.AddMatrix(matrix2);
    cout << "Sum of matrices:" << endl;
    sum.print();
    cout << endl;


    SparseMatrix product = matrix1.MultiplyMatrix(matrix2);
    cout << "Product of matrices:" << endl;
    product.print();
    cout << endl;

    SparseMatrix transposed = matrix1.transpose();
    cout << "Transposed Matrix 1:" << endl;
    transposed.print();
    cout << endl;

    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}