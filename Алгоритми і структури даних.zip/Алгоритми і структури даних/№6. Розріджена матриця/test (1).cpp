#include "pch.h"
#include "D:\my project\���_6_����\���_6_����\lab_6_Tsvyk.cpp"
TEST(SparseMatrixTest, ConstructorTest) {
    SparseMatrix matrix(3, 3);
    EXPECT_EQ(matrix.GetRowsHSize(), 3);
    EXPECT_EQ(matrix.GetColsHSize(), 3);
}


TEST(SparseMatrixTest, SetValueTest) {
    SparseMatrix matrix(3, 3);
    matrix.SetValue(1, 1, 5);
    EXPECT_EQ(matrix.GetValue(1, 1), 5);
}


TEST(SparseMatrixTest, DeleteValueTest) {
    SparseMatrix matrix(3, 3);
    matrix.SetValue(1, 1, 5);
    matrix.DeleteValue(1, 1);
    EXPECT_EQ(matrix.GetValue(1, 1), 0);
}
TEST(SparseMatrixTest, GetValueTest) {
    SparseMatrix matrix(3, 3);
    matrix.SetValue(0, 0, 1);
    matrix.SetValue(1, 1, 2);
    matrix.SetValue(2, 2, 3);

    
    EXPECT_EQ(matrix.GetValue(0, 0), 1);
    EXPECT_EQ(matrix.GetValue(1, 1), 2);
    EXPECT_EQ(matrix.GetValue(2, 2), 3);
}
TEST(SparseMatrixTest, AddMatrixWithDifferentSizesTest) {
    SparseMatrix matrix1(2, 3);
    matrix1.SetValue(0, 0, 1);
    matrix1.SetValue(0, 1, 2);
    matrix1.SetValue(1, 1, 3);

    SparseMatrix matrix2(3, 2);
    matrix2.SetValue(0, 0, 4);
    matrix2.SetValue(1, 1, 5);
    matrix2.SetValue(2, 1, 6);

    
    EXPECT_THROW(matrix1.AddMatrix(matrix2), const char*);
}




